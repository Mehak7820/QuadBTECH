const mongoose = require("mongoose");
try {
  mongoose.connect("mongodb+srv://jhaalok543:3pBEdlwQ1eYXvNXf@cluster0.4dr4eyn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  });
  console.log("Database Connected Successfully");
} catch (err) {
  console.log("Database Not Connected");
}
